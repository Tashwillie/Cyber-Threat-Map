#!/bin/bash
echo "🛑 Stopping Cyber Threat Map..."
pm2 stop cyber-threat-map
echo "✅ Application stopped!"