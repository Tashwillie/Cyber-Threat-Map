import { AttackEvent } from '../types/attack.js';
export declare function generateMockAttack(): AttackEvent;
export declare function generateMockAttacks(count: number): AttackEvent[];
//# sourceMappingURL=mockData.d.ts.map