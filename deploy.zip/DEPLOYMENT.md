# Cyber Threat Map - cPanel Deployment Instructions

## Prerequisites
- cPanel hosting with Node.js support
- Node.js 18+ installed on your hosting
- File Manager access in cPanel

## Deployment Steps

### 1. Upload Files
1. Upload all files from this deploy folder to your cPanel public_html directory
2. Extract the files maintaining the folder structure

### 2. Install Dependencies
1. Open Terminal in cPanel (or use SSH if available)
2. Navigate to your public_html directory
3. Run: `npm install`

### 3. Start the Application
1. In Terminal, run: `npm start`
2. The application will start on the configured port

### 4. Configure Domain (Optional)
1. If you want to use a subdomain, create it in cPanel
2. Point the subdomain to the public_html directory

### 5. SSL Certificate (Recommended)
1. Enable SSL in cPanel
2. Force HTTPS redirects

## File Structure After Deployment
```
public_html/
├── package.json
├── server/
│   ├── index.js
│   └── node_modules/
└── public/
    ├── index.html
    ├── assets/
    └── .htaccess
```

## Environment Variables
You can set these in cPanel Environment Variables:
- PORT: Server port (default: 3000)
- HOST: Server host (default: 0.0.0.0)

## Troubleshooting
- Check Node.js version: `node --version`
- Check if port is available: `netstat -tulpn | grep :3000`
- View logs in cPanel Error Logs
- Ensure all dependencies are installed: `npm list`

## Support
For issues, check the application logs and ensure all requirements are met.
