# Cyber Threat Map - Deployment Instructions

## 🚀 Quick Deploy

### Option 1: cPanel Deployment
1. Upload all files from this folder to your cPanel public_html directory
2. Extract maintaining folder structure
3. Open Terminal in cPanel
4. Run: `npm install`
5. Run: `npm start`
6. Access your site at your domain

### Option 2: VPS/Server Deployment
1. Upload files to your server
2. Install Node.js 18+
3. Run: `npm install`
4. Run: `npm start`
5. Configure reverse proxy (nginx/Apache) to point to port 3000

### Option 3: Docker Deployment
```bash
# Build Docker image
docker build -t cyber-threat-map .

# Run container
docker run -p 3000:3000 cyber-threat-map
```

## 🔧 Configuration

### Environment Variables
- PORT: Server port (default: 3000)
- HOST: Server host (default: 0.0.0.0)
- NODE_ENV: Environment (production/development)

### Features Included
✅ Responsive design for all screen sizes
✅ 55-inch display optimization
✅ Real-time attack simulation
✅ Interactive 2D world map
✅ Attack type legend
✅ Live statistics
✅ Mobile-friendly interface

## 📱 Responsive Scaling
- **Desktop (1920px+)**: 1.2x scale
- **Ultra-wide (2560px+)**: 1.4x scale  
- **4K/55-inch (3840px+)**: 1.6x scale

## 🛠 Troubleshooting
- Check Node.js version: `node --version`
- Check if port is available: `netstat -tulpn | grep :3000`
- View logs in cPanel Error Logs
- Ensure all dependencies are installed: `npm list`

## 📞 Support
For issues, check the application logs and ensure all requirements are met.
